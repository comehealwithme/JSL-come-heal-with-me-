from pathlib import Path
import math, random, re, json, zipfile
from reportlab.pdfgen import canvas
from reportlab.lib.colors import CMYKColor, HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from pypdf import PdfReader, PdfWriter
from pypdf.generic import RectangleObject

OUT=Path('output/pdf'); OUT.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('Serif','/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'))
pdfmetrics.registerFont(TTFont('SerifItalic','/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/share/fonts/truetype/NotoSerif-Italic.ttf'))
pdfmetrics.registerFont(TTFont('Sans','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('SansBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
QUESTIONS='''What is one childhood memory that still makes your heart feel warm?
When you were little, who made you feel the safest, and what did they do to create that feeling?
What did you love about yourself before the world started telling you who to be?
What did love look and sound like in your childhood home?
If you could spend one afternoon with your younger self, what would you want to do together?
When did you first feel that you had to be strong instead of simply being a child?
What emotions were you allowed to express growing up, and which ones did you learn to hide?
Did you grow up feeling loved for who you were or for how well you behaved?
What did you need from your parents or caregivers that they may not have known how to give?
What childhood experience taught you to stop asking for help?
When was the first time you remember feeling unwanted, rejected, or like a burden?
Who did you spend your childhood trying to make proud, and do you still seek their approval?
What part of your personality developed to protect you from being hurt?
Did you ever feel responsible for keeping peace in your family? How does that responsibility show up in your adult life?
What childhood hurt have you minimized because someone convinced you it wasn't that serious?
What happened in your childhood that you still struggle to speak about without feeling shame?
Who was supposed to protect you but failed to make you feel safe?
What did you have to sacrifice emotionally to survive the environment you grew up in?
If your younger self could confront the adults who hurt or disappointed them, what would they need those adults to understand?
What truth about your childhood have you been afraid to admit because acknowledging it would change how you see someone you love?
What does loyalty mean to you, and where did you learn that definition?
Who taught you what trust feels like?
How do you know when you feel emotionally safe with someone?
What is one relationship that changed the way you understand love?
What does rebuilding trust look like to you?
Have you ever forgiven someone while still carrying pain from what they did?
What betrayal made you question your own judgment?
Have you ever ignored a warning sign because you loved someone more than you trusted yourself?
What part of yourself did you begin hiding after someone broke your trust?
Have you ever stayed loyal to someone who repeatedly made you feel disposable?
Did the betrayal hurt more because of what happened or because of who did it?
What did someone's dishonesty make you believe about your worth?
Have you ever blamed yourself for another person's decision to hurt you? What would it take to release that blame?
What version of yourself disappeared after your deepest heartbreak?
Are you grieving the person who betrayed you, the relationship you had, or the future you imagined together?
What betrayal are you still emotionally living inside, even though the relationship or situation has ended?
Have you ever accepted disrespect because losing someone felt more painful than losing yourself?
What did you know deep down about someone but refuse to acknowledge because you weren't ready to let them go?
If the person who hurt you never apologizes or takes accountability, what would healing need to look like without their participation?
What did you lose in the betrayal besides the person, and what would it mean to begin reclaiming it?
What is something you wish people understood about you without needing an explanation?
What emotion is hardest for you to express honestly?
When do you feel most comfortable being your authentic self?
What conversation have you been postponing because you don't know where to begin?
What is something you've outgrown but haven't fully released?
What do you pretend doesn't bother you even though it deeply affects you?
Have you ever said “I'm okay” because explaining your pain felt exhausting?
Who do you struggle to be completely honest with, and what are you afraid their reaction might be?
What boundary have you avoided setting because you fear disappointing someone?
What resentment have you carried quietly, and what has it cost you emotionally?
What family behavior has everyone learned to normalize even though it causes pain?
Have you ever felt pressured to keep a family secret or protect someone's reputation at the expense of your own peace?
What have you been ashamed of that actually deserves compassion rather than judgment?
Who do you wish would acknowledge the pain they caused without making you defend your experience?
What have you wanted to say to someone for years but swallowed to avoid conflict?
What part of your story do you hide because you're afraid people will see you differently?
Have you ever felt that telling the truth about your pain would make you responsible for breaking your family apart?
What did you survive that people around you still expect you to act as though it never happened?
What truth about yourself or your relationships are you afraid to confront because it might require you to change your life?
If you could speak without fear of punishment, rejection, or retaliation, what would you finally say—and to whom?
What is one healthy habit or value from your upbringing that you want to carry forward?
What does a peaceful relationship look like to you?
How do you usually respond when someone disappoints you?
What behavior are you learning to recognize as a sign that you need stronger boundaries?
What is one pattern you've already begun changing that you're proud of?
Do you confuse being needed with being loved? Where might that belief have started?
When have you chosen someone else's comfort over your own emotional well-being?
Do you find yourself attracted to people who make you work hard for affection? What feels familiar about that dynamic?
What behavior did you learn growing up that once protected you but now creates distance in your relationships?
When you're afraid someone will leave, how does your behavior change?
What cycle in your family are you determined not to pass on to the next generation?
Have you ever pushed away someone who treated you well because healthy love felt unfamiliar?
What part of your own behavior do you need to take accountability for without shaming yourself?
Are you more afraid of being abandoned by someone else or of choosing yourself and walking away?
When have you mistaken emotional intensity for genuine connection?
In what ways have you unintentionally repeated the behavior of someone who hurt you?
Who have you hurt while trying to protect yourself from being hurt again, and what repair might be appropriate?
What unhealthy relationship pattern are you still participating in because changing it would require you to face loneliness or uncertainty?
What painful belief about love, family, or your own worth are you still allowing to make decisions for you?
If you stopped using your past as the only explanation for your present choices, what responsibility would you be ready to take for your healing?
What makes you feel safe, calm, and genuinely cared for today?
What is one thing you love about the person you're becoming?
What does your inner child need to hear from you this season?
When was the last time you felt proud of yourself for surviving something difficult?
What small act of kindness can you offer yourself this week?
What would change if you treated yourself with the same tenderness you offer people you love?
How can you begin giving yourself the emotional reassurance you once needed from others?
What does forgiveness mean to you when reconciliation is not safe, desired, or possible?
What part of your identity is ready to grow beyond the pain you've experienced?
What spiritual belief, prayer, or personal value helps you find strength when healing feels difficult?
What would it mean to stop waiting for someone else to validate your pain before you allow yourself to heal?
What have you been punishing yourself for that deserves understanding, accountability, or self-forgiveness instead?
If your younger self could see how you've survived, what do you hope they would feel?
What kind of love do you want to receive now, and what boundaries will help you recognize it?
What have you learned about God, faith, or your own sense of purpose through experiences that once made you question everything?
What are you still holding onto because releasing it feels like admitting that the past cannot be changed?
What would your life look like if your decisions were no longer guided primarily by fear, guilt, or the need to be chosen?
If healing requires grieving the childhood, relationships, or opportunities you deserved but never received, what are you ready to acknowledge?
What promise do you need to make to your younger self—and what action will prove that you're keeping it?
If you could sit face-to-face with every version of yourself that survived pain, betrayal, rejection, and loneliness, what would you say to them before inviting them into the life you're creating now?'''.splitlines()
assert len(QUESTIONS)==100
CHAPTERS=['The Child Within','The Betrayal That Changed Me','The Truth I Never Spoke','The Patterns I Must Break','Becoming Whole Again']
LEVELS=['GENTLE REFLECTION','LOOKING DEEPER','DEEPER WOUNDS','RAW TRUTHS']
MESSAGE='You survived what tried to break you. Now give yourself permission to heal.'
SPECIAL=[('Permission to Pause','My healing does not require me to share more than I am ready to. I am allowed to pause, breathe, and protect my peace.'),('Release','What am I ready to stop carrying today, even if I am not yet ready to let it go completely?'),('Closing Prayer','God, meet us in the places where words have been difficult. Give us wisdom to recognize what needs care, courage to face what we can, and grace to heal at our own pace. Amen.'),('A Message for You',MESSAGE)]
PINK=CMYKColor(.04,.27,.16,.0); ROSE=CMYKColor(.1,.42,.27,.08); SOFT=CMYKColor(.02,.19,.12,0)
BROWN=CMYKColor(.24,.49,.51,.64); BLACK=CMYKColor(0,0,0,.95); GOLD=CMYKColor(.12,.35,.32,.07)
INK=CMYKColor(0,0,0,.92); CREAM=CMYKColor(.01,.05,.04,0)
COLORS=[PINK,BROWN,BLACK,ROSE,SOFT]
W,H=252,360

def para(c,text,x,y,width,size=16,color=INK,font='Serif',maxh=None):
    while True:
        st=ParagraphStyle('p',fontName=font,fontSize=size,leading=size*1.38,textColor=color,alignment=TA_CENTER)
        p=Paragraph(text,st); _,ht=p.wrap(width,1000)
        if maxh is None or ht<=maxh: break
        size-=.25
        assert size>=11
    p.drawOn(c,x,y-ht); return ht

def butterfly(c,x,y,s=1,color=GOLD):
    c.saveState(); c.translate(x,y); c.scale(s,s);c.setStrokeColor(color);c.setFillColor(color);c.setLineWidth(.65)
    for sign in [-1,1]:
        p=c.beginPath();p.moveTo(0,0);p.curveTo(sign*10,21,sign*32,23,sign*27,5);p.curveTo(sign*23,-4,sign*10,-4,0,0);c.drawPath(p,stroke=1,fill=0)
        p=c.beginPath();p.moveTo(0,0);p.curveTo(sign*12,-1,sign*21,-12,sign*13,-17);p.curveTo(sign*4,-19,sign*2,-4,0,0);c.drawPath(p,stroke=1,fill=0)
        c.line(0,3,sign*5,12)
    c.ellipse(-1,-8,1,7,stroke=0,fill=1);c.restoreState()

def marble(c,base,seed,bleed=0):
    c.setFillColor(base);c.rect(-bleed,-bleed,W+2*bleed,H+2*bleed,fill=1,stroke=0)
    rng=random.Random(seed)
    # Flowing mineral bands are kept at the edges so the question remains clear.
    for edge in [0,W]:
        for i in range(13):
            x=edge+(-1 if edge==W else 1)*(i*3-20)
            c.setStrokeColor(GOLD if i%5==0 else (PINK if base in [BROWN,BLACK] else BROWN))
            c.setStrokeAlpha(.35 if i%5==0 else .12)
            c.setLineWidth(.6 if i%5==0 else rng.uniform(1,5))
            p=c.beginPath();p.moveTo(x,-bleed)
            p.curveTo(x+45,H*.25,x-40,H*.55,x+20,H*.75)
            p.curveTo(x+45,H*.9,x+8,H,x+35,H+bleed)
            c.drawPath(p)
    c.setStrokeAlpha(1)

def card(c,index,back=False,bleed=0):
    c.saveState()
    clip=c.beginPath();clip.rect(-bleed,-bleed,W+2*bleed,H+2*bleed)
    c.clipPath(clip,stroke=0,fill=0)
    chapter=min(index//20,4) if index<100 else 2
    bg=COLORS[chapter]; dark=chapter in [1,2]
    if back:
        marble(c,BLACK,71,bleed)
        c.setStrokeColor(GOLD);c.setLineWidth(.7);c.roundRect(14,14,W-28,H-28,14,stroke=1,fill=0)
        c.setLineWidth(.3);c.roundRect(19,19,W-38,H-38,12,stroke=1,fill=0)
        butterfly(c,W/2,287,.83)
        c.setFillColor(PINK);c.setFont('Serif',52);c.drawCentredString(W/2,218,'JSL')
        para(c,'Come Heal<br/>With Me',27,194,W-54,24,PINK)
        c.setStrokeColor(GOLD);c.line(88,101,164,101)
        para(c,'HEAL  •  REFLECT<br/>RELEASE  •  REBUILD',25,83,W-50,8,GOLD,'Sans')
        para(c,'A space to tell the truth.',22,44,W-44,8.5,CREAM,'SerifItalic')
    else:
        marble(c,bg,chapter+18,bleed)
        # An opaque central field gives long questions a quiet, readable surface.
        c.setFillColor(bg);c.roundRect(26,70,W-52,196,9,stroke=0,fill=1)
        c.setStrokeColor(GOLD if dark else BROWN);c.setLineWidth(.6);c.roundRect(14,14,W-28,H-28,14,stroke=1,fill=0)
        color=CREAM if dark else INK
        c.setFillColor(GOLD if dark else BROWN);c.setFont('Serif',17);c.drawCentredString(W/2,322,'JSL')
        if index<100:
            title=CHAPTERS[chapter]; label=f'CHAPTER {chapter+1:02d}'; question=QUESTIONS[index]
            level=LEVELS[(index%20)//5]
            if index>=95: level='RAW TRUTHS & RELEASE'
        else:
            title,question=SPECIAL[index-100];label='BOX INSERT' if index==103 else 'SUPPORT CARD';level='YOUR PACE. YOUR PERMISSION.'
        para(c,label,22,307,W-44,7.2,GOLD if dark else BROWN,'SansBold')
        para(c,title,24,291,W-48,11.2,color,'SerifItalic')
        c.setFillColor(GOLD if dark else BROWN); c.circle(W/2-12,254,1.1,fill=1,stroke=0);c.circle(W/2,254,1.1,fill=1,stroke=0);c.circle(W/2+12,254,1.1,fill=1,stroke=0)
        st=ParagraphStyle('q',fontName='Serif',fontSize=16,leading=22.08,alignment=TA_CENTER,textColor=color)
        p=Paragraph(question,st);_,ht=p.wrap(W-64,1000)
        size=16
        while ht>158:
            size-=.25;st.fontSize=size;st.leading=size*1.38;p=Paragraph(question,st);_,ht=p.wrap(W-64,1000)
        assert size>=11.5,(index,size)
        p.drawOn(c,32,164-ht/2)
        butterfly(c,W/2,65,.35,GOLD if dark else BROWN)
        para(c,level,20,43,W-40,6.4,GOLD if dark else BROWN,'SansBold')
        c.setFillColor(color);c.setFont('Sans',7.5);c.drawString(23,25,'COME HEAL WITH ME')
        c.setFont('SansBold',8);c.drawRightString(W-23,25,f'{index+1:03d}' if index<100 else ['PAUSE','RELEASE','PRAYER','JSL'][index-100])
    c.restoreState()

def printer():
    path=OUT/'JSL_Come_Heal_With_Me_Printer.pdf'
    temp=OUT/'temp.pdf'; c=canvas.Canvas(str(temp),pagesize=(W+18,H+18),pageCompression=1)
    c.setTitle('JSL - Come Heal With Me | Printer cards | 3.5 x 5 in')
    for i in range(104):
        for back in [False,True]:
            c.saveState();c.translate(9,9);card(c,i,back,9);c.restoreState();c.showPage()
    c.save(); r=PdfReader(str(temp));w=PdfWriter()
    for p in r.pages:
        p.trimbox=RectangleObject([9,9,W+9,H+9]);p.bleedbox=RectangleObject([0,0,W+18,H+18]);w.add_page(p)
    w.add_metadata({'/Title':'JSL - Come Heal With Me | Printer deck','/Author':'JSL'})
    with path.open('wb') as f:w.write(f)
    temp.unlink()

def home():
    path=OUT/'JSL_Come_Heal_With_Me_Home_Print.pdf';c=canvas.Canvas(str(path),pagesize=(612,792),pageCompression=1)
    c.setTitle('JSL - Come Heal With Me | Letter duplex | Actual size')
    # Mirrored back artwork; identical backs also prevent accidental identity cues.
    for batch in range(26):
        for back in [False,True]:
            for row in range(2):
                for col in range(2):
                    i=batch*4+row*2+(1-col if back else col)
                    x=45+col*270;y=27+(1-row)*378
                    c.saveState();c.translate(x,y)
                    # Bleed fills the gap; trim ticks remain outside artwork.
                    card(c,i,back,5)
                    c.setStrokeColor(INK);c.setLineWidth(.4)
                    for xx in [0,W]:
                        for yy in [0,H]:
                            sx=-1 if xx==0 else 1;sy=-1 if yy==0 else 1
                            c.line(xx+sx*6,yy,xx+sx*10,yy);c.line(xx,yy+sy*6,xx,yy+sy*10)
                    c.restoreState()
            c.setFont('Sans',6);c.setFillColor(INK);c.drawCentredString(306,9,f'JSL • Sheet {batch+1:02d}/26 • '+('BACKS' if back else 'FRONTS')+' • Print 100%, portrait, flip long edge')
            c.showPage()
    c.save()

def guide():
    path=OUT/'JSL_Come_Heal_With_Me_Guide.pdf';c=canvas.Canvas(str(path),pagesize=(612,792))
    def page(title,sub):
        c.setFillColor(CREAM);c.rect(0,0,612,792,fill=1,stroke=0)
        c.setFillColor(BLACK);c.rect(0,667,612,125,fill=1,stroke=0)
        c.setFillColor(PINK);c.setFont('Serif',21);c.drawString(42,744,'JSL • Come Heal With Me')
        c.setFont('Serif',17);c.drawString(42,705,title)
        c.setFillColor(BROWN);c.setFont('Sans',9);c.drawString(42,638,sub)
    def text(t,y,size=11):
        p=Paragraph(t,ParagraphStyle('body',fontName='Sans',fontSize=size,leading=size*1.5,textColor=INK))
        _,h=p.wrap(528,700);p.drawOn(c,42,y-h);return y-h-14
    page('How to Play','1–8 PLAYERS • AGES 18+ • NO SCORING • GO AT YOUR OWN PACE')
    y=608
    for t in ['<b>Begin with care.</b> Agree on respectful listening and privacy. Ask everyone whether they feel ready to participate. Sharing is always voluntary.',
        '<b>1. Choose a chapter.</b> Start with Chapter One, or select the theme you want to explore.',
        '<b>2. Move gently.</b> Read in numerical order for the intended gentle-to-raw progression. Shuffle within a depth level if you want variety; shuffling an entire chapter mixes the emotional intensity.',
        '<b>3. Read and reflect.</b> One person reads a question aloud and answers at their own pace. Play alone by journaling, or take turns in a group.',
        '<b>4. Listen.</b> Do not interrupt, correct, judge, or give unsolicited advice. Ask: “Do you want to be heard, comforted, or supported in finding a solution?”',
        '<b>5. Keep your choice.</b> Pass, pause, journal privately, or end the game at any time without explanation. No one has to tell the whole story.',
        '<b>6. Close with care.</b> Feel your feet on the floor, notice the room, and breathe at a comfortable pace. Offer an affirmation, a quiet moment, or the optional prayer. There is no requirement to pray.',
        '<b>Care agreement.</b> Do not pressure anyone to disclose, forgive, or reconcile. Agree on confidentiality, while recognizing that absolute secrecy cannot be guaranteed. This game supports reflection and connection; it is not a replacement for professional trauma therapy.']:
        y=text(t,y,10.5)
    assert y>36,y
    c.showPage()
    page('Five Healing Chapters','100 NUMBERED QUESTIONS + 3 SUPPORT CARDS + 1 INSIDE-BOX INSERT')
    y=602
    desc=['Childhood memories, emotional safety, family, abandonment, and unmet needs.','Broken trust, heartbreak, loyalty, disappointment, and emotional safety.','Shame, silence, resentment, family secrets, and difficult conversations.','Generational patterns, attachment, boundaries, accountability, and change.','Inner-child care, self-compassion, rebuilding trust, spirituality, and a different future.']
    for i in range(5):
        c.setFillColor(COLORS[i]);c.roundRect(42,y-14,12,12,2,fill=1,stroke=0)
        y=text(f'<b>{i+1:02d} • {CHAPTERS[i]}</b> | Cards {i*20+1:03d}–{(i+1)*20:03d}<br/>{desc[i]}',y-1,11)-6
    y=text('<b>Four depths in each chapter</b><br/>First five: Gentle Reflection • Next five: Looking Deeper<br/>Next five: Deeper Wounds • Last five: Raw Truths<br/>Cards 096–100 close with Raw Truths &amp; Release.',y,10.5)
    y=text('<b>The support cards</b><br/>Permission to Pause: a reminder that your pace matters.<br/>Release: an invitation to set down what you can today.<br/>Closing Prayer: optional faith-based closure.',y,10.5)
    y=text('<b>Your inside-box message</b><br/>'+MESSAGE,y,11)
    c.showPage()
    page('Printing and Finishing','FINISHED CARD SIZE: 3½ × 5 INCHES (88.9 × 127 MM)')
    y=608
    for t in ['<b>Commercial printer file</b><br/>208 pages: each front is immediately followed by its matching back. Pages 1–200 are the 100 questions; 201–206 are the three support cards; 207–208 are the inside-box insert. Each PDF page is 3¾ × 5¼ inches, including ⅛-inch bleed on all edges. TrimBox is 3½ × 5 inches. There are no crop marks in this file; the printer should use the PDF TrimBox.',
        '<b>Production specification</b><br/>Fonts are embedded. Artwork uses process CMYK colors; rose-gold is a printed color, not metallic foil. The PDF is not certified PDF/X and has no assigned output profile. Ask the printer to preflight and convert to their preferred profile. Request a physical color and duplex proof before the full run. Suggested stock: opaque 300–350 gsm card stock with matte finishing, subject to printer suitability. Optional ⅛-inch corner rounding stays clear of the text.',
        '<b>Home-print file</b><br/>US Letter, 52 pages, four cards per sheet. Odd pages are fronts; even pages are backs. Print portrait at Actual Size / 100% with duplex “flip on long edge.” Turn off Fit / Shrink / Scale to Page. The artwork includes a small bleed around each card and cutting ticks outside the trim. Use card stock your printer supports.',
        '<b>Test before printing the deck</b><br/>Print pages 1–2 first. Hold them against a light to check that fronts and backs line up. Confirm a cut card measures 3½ × 5 inches. Printer feed may cause slight registration drift; adjust your device settings if needed. Cut along the outside ticks using a ruler and paper trimmer.',
        '<b>Inside-box insert</b><br/>The final card is the message insert. Place it inside the box lid or above the deck. It is separate from the 100 questions. A box manufacturing dieline is not included; a box supplier must size the box for the final stock thickness and finishing.',
        '<b>Included source</b><br/>The complete bundle includes the editable generation script and question data, alongside all three PDFs. The numbered wording follows your approved deck.']:
        y=text(t,y,10)
    assert y>30,y
    c.showPage();c.save()

printer();home();guide()
data={'title':'JSL - Come Heal With Me','trim_inches':[3.5,5],'inside_box_message':MESSAGE,'cards':[{'number':i+1,'chapter':CHAPTERS[i//20],'question':q} for i,q in enumerate(QUESTIONS)],'support_cards':[{'title':t,'wording':q} for t,q in SPECIAL[:3]]}
(OUT/'JSL_Questions.json').write_text(json.dumps(data,indent=2,ensure_ascii=False))
with zipfile.ZipFile(OUT/'JSL_Come_Heal_With_Me_Complete.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.glob('*.pdf'):z.write(p,p.name)
    z.write(OUT/'JSL_Questions.json','JSL_Questions.json');z.write(__file__,'build_deck.py')
for p in OUT.glob('*.pdf'):
    r=PdfReader(str(p)); print(p.name,len(r.pages),'pages',p.stat().st_size,'bytes')
